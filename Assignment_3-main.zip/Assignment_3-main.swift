func myfunc1()
{
    for i in 1...5
  {

    for j in 1...i
    {
      print(j," ",terminator : "")
    }
    print(" ")
  }
}
func myfunc2()
{
  var k = 1
  for i in 1...5
  {
    for j in 1...i
    {
       print(k," ",terminator : "")
    k=k+1
    }
   print(" ")
  }
}
func myfunc3()
{
  for i in 1...5{
    var temp = 1

    for k in 1...i{
        print(temp," ",terminator : "")
         temp = temp * (i - k) / (k);
    }
    print(" ")
}
}

print("First")
 myfunc1()
 print("Second")
 myfunc2()
 print("Third")
 myfunc3()